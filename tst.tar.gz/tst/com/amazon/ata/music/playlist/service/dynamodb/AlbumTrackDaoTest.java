package com.amazon.ata.music.playlist.service.dynamodb;

//import com.amazon.ata.music.playlist.service.dynamodb.models.AlbumTrack;
//import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
//import org.junit.jupiter.api.*;
//import org.mockito.*;
//
//import static org.mockito.Mockito.*;
//
////MARKER: stubbed this for MT4
//class AlbumTrackDaoTest {
//    @Mock
//    DynamoDBMapper dynamoDbMapper;
//    @InjectMocks
//    AlbumTrackDao  albumTrackDao;
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    void testGetAlbumTrack() {
//        AlbumTrack result = albumTrackDao.getAlbumTrack("albumId", "trackId");
//        Assertions.assertEquals(new AlbumTrack(), result);
//    }
//}
//
